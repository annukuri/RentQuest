package com.proj.rentquest;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.json.JSONException;
import org.json.JSONObject;

import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;


public class AddRent extends Activity implements View.OnClickListener {

    private static final String URL = "http://" + Config.ipAddress + "/RentQuestWeb/AddRent.php"; // Replace with your PHP registration URL

    private LocationManager locationManager;
    private LocationListener locationListener;


    String name, owner, address, phone, bhk, rent, landmark, desc, lat, lan;

    String response = null;

    EditText etName, etOwner, etAddress, etPhone, etBhk, etRent, etLandMark, etDesc, etUid, editTextLatitude, editTextLongitude;
    Button btnAddRent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addrent);
        Config.idforproperty = getUniqueID();

        etUid = (EditText) findViewById(R.id.etUid);
        etName = (EditText) findViewById(R.id.etName);
        etOwner = (EditText) findViewById(R.id.etOwner);
        etAddress = (EditText) findViewById(R.id.etAdd);
        etPhone = (EditText) findViewById(R.id.etPhone);
        etBhk = (EditText) findViewById(R.id.etBhk);
        etRent = (EditText) findViewById(R.id.etRent);
        etLandMark = (EditText) findViewById(R.id.etLandMark);
        etDesc = (EditText) findViewById(R.id.etDesc);
        editTextLatitude = (EditText) findViewById(R.id.editTextLatitude);
        editTextLongitude = (EditText) findViewById(R.id.editTextLongitude);

        etUid.setText(Config.idforproperty);

        btnAddRent = (Button) findViewById(R.id.btnAddRent);
        btnAddRent.setOnClickListener(this);



        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                double latitude = location.getLatitude();
                double longitude = location.getLongitude();
                // Do something with the latitude and longitude values
                // For example, display them in a TextView
                editTextLatitude.setText(""+latitude);
                editTextLongitude.setText(""+longitude);
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {
            }

            @Override
            public void onProviderEnabled(String provider) {
            }

            @Override
            public void onProviderDisabled(String provider) {
            }
        };

        // Check location permission
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // Request location permission if not granted
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        } else {
            // Request location updates
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
        }

    }

    private String getUniqueID() {
        String prefix = "PROP";
        int numberLength = 10 - prefix.length();
        Random random = new Random();
        int randomNumber = random.nextInt((int) Math.pow(10, numberLength));
        String formattedNumber = String.format("%0" + numberLength + "d", randomNumber);
        String finalNumber = prefix + formattedNumber;
        return finalNumber;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnAddRent:

                name = this.etName.getText().toString();
                address = this.etAddress.getText().toString();
                owner = this.etOwner.getText().toString();
                phone = this.etPhone.getText().toString();
                bhk = this.etBhk.getText().toString();
                rent = this.etRent.getText().toString();
                landmark = this.etLandMark.getText().toString();
                lat = this.editTextLatitude.getText().toString();
                lan = this.editTextLongitude.getText().toString();
                desc = this.etDesc.getText().toString();
                addProperty(Config.idforproperty, name, owner, address, phone, bhk, rent, landmark, desc, lat, lan);
                break;
        }
    }


    private void addProperty(String uid, String name, String owner, String address, String phone, String bhk, String rent, String landmark, String desc, String lat, String lan) {

        StringRequest request = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            boolean success = jsonObject.getBoolean("success");
                            String message = jsonObject.getString("message");

                            if(success){
                                Toast.makeText(AddRent.this, message, Toast.LENGTH_SHORT).show();
                                Intent addrentimg = new Intent(AddRent.this, AddRentImage.class);
                                addrentimg.putExtra("PropID",Config.idforproperty);
                                startActivity(addrentimg);
                            }else{
                                Toast.makeText(AddRent.this, "Cannot Add", Toast.LENGTH_SHORT).show();
                            }



                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        // Handle the response from the server


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(AddRent.this, "Registration failed" + error.toString(), Toast.LENGTH_SHORT).show();
                        // Handle error
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                //bhk, rent, landmark, desc
                Map<String, String> params = new HashMap<>();
                params.put("uid", uid);
                params.put("name", name);
                params.put("owner", owner);
                params.put("address", address);
                params.put("phone", phone);
                params.put("bhk", bhk);
                params.put("landmark", landmark);
                params.put("descn", desc);
                params.put("rent", rent);
                params.put("lat", lat);
                params.put("lan", lan);

                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Request location updates
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
                }
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Remove location updates to conserve battery life
        locationManager.removeUpdates(locationListener);
    }
}