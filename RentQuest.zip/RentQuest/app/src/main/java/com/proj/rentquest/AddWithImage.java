package com.proj.rentquest;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.provider.MediaStore;

import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;


import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.UUID;

public class AddWithImage extends Activity implements LocationListener {

    private static final int PICK_IMAGE_REQUEST = 1;
    private ImageView imageView;
    private EditText etName, etOwner, etAddress, etPhone, etBhk, etRent, etLandMark, etDesc, editLatitude, editLongitude;
    private Button buttonUpload;
    private Bitmap bitmap;
    private final String uploadUrl = "http://" + Config.ipAddress + "/RentQuestWeb/UploadProperty.php"; // Replace with your PHP server URL
    private LocationManager locationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addwithimage);

        imageView = findViewById(R.id.imageView);
        etName = findViewById(R.id.etName);
        etOwner = findViewById(R.id.etOwner);
        etAddress = findViewById(R.id.etAdd);
        etPhone = findViewById(R.id.etPhone);
        etBhk = findViewById(R.id.etBhk);
        etRent = findViewById(R.id.etRent);
        etLandMark = findViewById(R.id.etLandMark);
        etDesc = findViewById(R.id.etDesc);
        editLatitude = findViewById(R.id.etlatitude);
        editLongitude = findViewById(R.id.etlongitude);

        buttonUpload = findViewById(R.id.buttonUpload);

        //locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        } else {
            // Start retrieving location
            startLocationUpdates();
        }

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open gallery to select an image
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Image"), PICK_IMAGE_REQUEST);
            }
        });

        buttonUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Upload the selected image with text data
                uploadImage();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try {
                // Get the selected image
                Uri filePath = data.getData();
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                imageView.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void uploadImage() {
        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);

        // Generate a random boundary
        final String boundary = UUID.randomUUID().toString();

        // Convert image to base64 string
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
        byte[] imageBytes = byteArrayOutputStream.toByteArray();
        final String imageString = Base64.encodeToString(imageBytes, Base64.DEFAULT);

        // Get text parameters
        String name = etName.getText().toString().trim();
        String owner = etOwner.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String address = etAddress.getText().toString().trim();
        String bhk = this.etBhk.getText().toString();
        String rent = this.etRent.getText().toString();
        String landmark = this.etLandMark.getText().toString();
        String desc = this.etDesc.getText().toString();
        String latitude = this.editLatitude.getText().toString();
        String longitude = this.editLongitude.getText().toString();

        // Create a multipart request
        StringRequest multipartRequest = new StringRequest(Request.Method.POST, uploadUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(AddWithImage.this, response, Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(AddWithImage.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            public String getBodyContentType() {
                return "multipart/form-data;boundary=" + boundary;
            }

            @Override
            public byte[] getBody() throws AuthFailureError {
                try {
                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                    DataOutputStream dataOutputStream = new DataOutputStream(outputStream);

                    // Add text parameters
                    dataOutputStream.writeBytes("--" + boundary + "\r\n");
                    dataOutputStream.writeBytes("Content-Disposition: form-data; name=\"name\"\r\n\r\n");
                    dataOutputStream.writeBytes(name + "\r\n");

                    dataOutputStream.writeBytes("--" + boundary + "\r\n");
                    dataOutputStream.writeBytes("Content-Disposition: form-data; name=\"owner\"\r\n\r\n");
                    dataOutputStream.writeBytes(owner + "\r\n");

                    dataOutputStream.writeBytes("--" + boundary + "\r\n");
                    dataOutputStream.writeBytes("Content-Disposition: form-data; name=\"address\"\r\n\r\n");
                    dataOutputStream.writeBytes(address + "\r\n");

                    dataOutputStream.writeBytes("--" + boundary + "\r\n");
                    dataOutputStream.writeBytes("Content-Disposition: form-data; name=\"phone\"\r\n\r\n");
                    dataOutputStream.writeBytes(phone + "\r\n");

                    dataOutputStream.writeBytes("--" + boundary + "\r\n");
                    dataOutputStream.writeBytes("Content-Disposition: form-data; name=\"bhk\"\r\n\r\n");
                    dataOutputStream.writeBytes(bhk + "\r\n");

                    dataOutputStream.writeBytes("--" + boundary + "\r\n");
                    dataOutputStream.writeBytes("Content-Disposition: form-data; name=\"rent\"\r\n\r\n");
                    dataOutputStream.writeBytes(rent + "\r\n");

                    dataOutputStream.writeBytes("--" + boundary + "\r\n");
                    dataOutputStream.writeBytes("Content-Disposition: form-data; name=\"landmark\"\r\n\r\n");
                    dataOutputStream.writeBytes(landmark + "\r\n");

                    dataOutputStream.writeBytes("--" + boundary + "\r\n");
                    dataOutputStream.writeBytes("Content-Disposition: form-data; name=\"desc\"\r\n\r\n");
                    dataOutputStream.writeBytes(desc + "\r\n");

                    dataOutputStream.writeBytes("--" + boundary + "\r\n");
                    dataOutputStream.writeBytes("Content-Disposition: form-data; name=\"latitude\"\r\n\r\n");
                    dataOutputStream.writeBytes(latitude + "\r\n");

                    dataOutputStream.writeBytes("--" + boundary + "\r\n");
                    dataOutputStream.writeBytes("Content-Disposition: form-data; name=\"longitude\"\r\n\r\n");
                    dataOutputStream.writeBytes(longitude + "\r\n");

                    // Add image data
                    dataOutputStream.writeBytes("--" + boundary + "\r\n");
                    dataOutputStream.writeBytes("Content-Disposition: form-data; name=\"image\"; filename=\"image" + new Date().getTime() + ".jpg\"\r\n");
                    dataOutputStream.writeBytes("Content-Type: image/jpeg\r\n\r\n");
                    dataOutputStream.write(Base64.decode(imageString, Base64.DEFAULT));
                    dataOutputStream.writeBytes("\r\n");

                    // End boundary
                    dataOutputStream.writeBytes("--" + boundary + "--\r\n");

                    return outputStream.toByteArray();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                try {
                    String responseBody = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    return Response.success(responseBody, HttpHeaderParser.parseCacheHeaders(response));
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }

                return Response.error(new VolleyError("Error parsing network response"));
            }
        };

        // Add the request to the RequestQueue
        queue.add(multipartRequest);
    }

    @SuppressLint("MissingPermission")
    private void startLocationUpdates() {

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 10, this);
        Location lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        if (lastKnownLocation != null) {
            double latitude = lastKnownLocation.getLatitude();
            double longitude = lastKnownLocation.getLongitude();
            editLatitude.setText(String.valueOf(latitude));
            editLongitude.setText(String.valueOf(longitude));
        }
    }

    @Override
    public void onLocationChanged(Location location) {

       if (location != null) {
            double latitude = location.getLatitude();
            double longitude = location.getLongitude();

            editLatitude.setText(String.valueOf(latitude));
            editLongitude.setText(String.valueOf(longitude));
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, start retrieving location
                startLocationUpdates();
            } else {
                Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @SuppressLint("MissingPermission")
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Stop location updates to avoid memory leaks
        if (locationManager != null) locationManager.removeUpdates(this);
    }
}
