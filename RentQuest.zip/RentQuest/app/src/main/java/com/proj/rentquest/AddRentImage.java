package com.proj.rentquest;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.UUID;

public class AddRentImage extends Activity  {

    private static final int PICK_IMAGE_REQUEST = 1;
    private ImageView imageView;
    private Button buttonUpload;
    private Bitmap bitmap;
    private final String uploadUrl = "http://" + Config.ipAddress + "/RentQuestWeb/AddRentImage.php"; // Replace with your PHP server URL
    EditText etPropName;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addrentimage);
        imageView = findViewById(R.id.imageView);
        etPropName = findViewById(R.id.etPropId);
        buttonUpload = findViewById(R.id.buttonUpload);


        Intent i = getIntent();
        String pid = i.getStringExtra("PropID");
        etPropName.setText(pid);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open gallery to select an image
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Image"), PICK_IMAGE_REQUEST);
            }
        });
        buttonUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Upload the selected image with text data
                uploadImage();
            }
        });

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try {
                // Get the selected image
                Uri filePath = data.getData();
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                imageView.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void uploadImage() {
        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);

        // Generate a random boundary
        final String boundary = UUID.randomUUID().toString();

        // Convert image to base64 string
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
        byte[] imageBytes = byteArrayOutputStream.toByteArray();
        final String imageString = Base64.encodeToString(imageBytes, Base64.DEFAULT);

        // Get text parameters
        String propertyid = etPropName.getText().toString().trim();


        // Create a multipart request
        StringRequest multipartRequest = new StringRequest(Request.Method.POST, uploadUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(AddRentImage.this, response, Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(AddRentImage.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            public String getBodyContentType() {
                return "multipart/form-data;boundary=" + boundary;
            }

            @Override
            public byte[] getBody() throws AuthFailureError {
                try {
                    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                    DataOutputStream dataOutputStream = new DataOutputStream(outputStream);

                    // Add text parameters
                    dataOutputStream.writeBytes("--" + boundary + "\r\n");
                    dataOutputStream.writeBytes("Content-Disposition: form-data; name=\"propertyid\"\r\n\r\n");
                    dataOutputStream.writeBytes(propertyid + "\r\n");

                    // Add image data
                    dataOutputStream.writeBytes("--" + boundary + "\r\n");
                    dataOutputStream.writeBytes("Content-Disposition: form-data; name=\"image\"; filename=\"image" + new Date().getTime() + ".jpg\"\r\n");
                    dataOutputStream.writeBytes("Content-Type: image/jpeg\r\n\r\n");
                    dataOutputStream.write(Base64.decode(imageString, Base64.DEFAULT));
                    dataOutputStream.writeBytes("\r\n");

                    // End boundary
                    dataOutputStream.writeBytes("--" + boundary + "--\r\n");

                    return outputStream.toByteArray();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                try {
                    String responseBody = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    return Response.success(responseBody, HttpHeaderParser.parseCacheHeaders(response));
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }

                return Response.error(new VolleyError("Error parsing network response"));
            }
        };

        // Add the request to the RequestQueue
        queue.add(multipartRequest);
    }

}
