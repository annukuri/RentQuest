package com.proj.rentquest;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class SearchProperty extends Activity {

    private Spinner spinner;
    private EditText searchQueryEditText;
    private Button searchButton;
    private ListView listView;
    private List<Property> searchResults;
    private PropertyAdapter listViewAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.searchprop);

        spinner = findViewById(R.id.spinner);
        searchQueryEditText = findViewById(R.id.etSearch);
        searchButton = findViewById(R.id.btnSearch);
        listView = findViewById(R.id.lstViewAllProperty);

        // Initialize the search results list and adapter
        searchResults = new ArrayList<>();
        listViewAdapter = new PropertyAdapter();

        // Set the adapter to the ListView
        listView.setAdapter(listViewAdapter);

        // Load spinner options
        loadSpinnerOptions();

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String searchQuery = searchQueryEditText.getText().toString();
                // Perform search based on selected spinner option and search query
                performSearch(spinner.getSelectedItem().toString(), searchQuery);
            }
        });

        // Set item click listener for ListView
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Get the clicked property
                Property property = searchResults.get(position);


                StringBuilder toastMessage = new StringBuilder();
                toastMessage.append("Unique ID: ").append(property.getUniqueid()).append("\n");
                toastMessage.append("Name: ").append(property.getName()).append("\n");
                toastMessage.append("Owner: ").append(property.getOwner()).append("\n");
                toastMessage.append("Address: ").append(property.getAddress()).append("\n");
                toastMessage.append("Phone: ").append(property.getPhone()).append("\n");
                toastMessage.append("Rent: ").append(property.getRent()).append("\n");
                toastMessage.append("BHK: ").append(property.getBhk()).append("\n");
                toastMessage.append("Landmark: ").append(property.getLandmark()).append("\n");
                toastMessage.append("Latitude: ").append(property.getLatitude()).append("\n");
                toastMessage.append("Longitude: ").append(property.getLongitude()).append("\n");
                toastMessage.append("Description: ").append(property.getDescription());

                // Show the toast message with longer duration
                Toast.makeText(SearchProperty.this, toastMessage.toString(), Toast.LENGTH_LONG).show();


                // Start the next activity and pass the property data
                Intent intent = new Intent(SearchProperty.this, PropertyDetailsActivity.class);
                intent.putExtra("uniqueid", property.getUniqueid());
                intent.putExtra("name", property.getName());
                intent.putExtra("owner", property.getOwner());
                intent.putExtra("address", property.getAddress());
                intent.putExtra("phone", property.getPhone());
                intent.putExtra("rent", property.getRent());
                intent.putExtra("bhk", property.getBhk());
                intent.putExtra("landmark", property.getLandmark());
                intent.putExtra("latitude", property.getLatitude());
                intent.putExtra("longitude", property.getLongitude());
                intent.putExtra("desc", property.getDescription());
                startActivity(intent);
            }
        });
    }

    private void loadSpinnerOptions() {
        // Options for spinner
        List<String> options = new ArrayList<>();
        options.add("Select");
        options.add("rentpermonth");
        options.add("bhk");
        options.add("landmark");
        options.add("address");

        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, options);

        // Specify the layout to use when the list of choices appears
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Apply the adapter to the spinner
        spinner.setAdapter(spinnerAdapter);
    }

    private void performSearch(String selectedOption, String searchQuery) {
        // Your PHP script URL
        String url = "http://" + Config.ipAddress + "/RentQuestWeb/GetFilteredRent.php?selectedOption=" + selectedOption + "&searchQuery=" + searchQuery;

        // Create a new RequestQueue
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        // Create a new JsonArrayRequest
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        // Clear previous search results
                        searchResults.clear();

                        // Iterate through the JSON array
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                // Get each JSON object
                                JSONObject jsonObject = response.getJSONObject(i);

                                // Extract the property details
                                String uid = jsonObject.getString("uniqueid");
                                String name = jsonObject.getString("name");
                                String owner = jsonObject.getString("owner");
                                String address = jsonObject.getString("address");
                                String phone = jsonObject.getString("phone");
                                String rent = jsonObject.getString("rentpermonth");
                                String bhk = jsonObject.getString("bhk");
                                String landmark = jsonObject.getString("landmark");
                                String latitude = jsonObject.getString("latitude");
                                String longitude = jsonObject.getString("longitude");
                                String desc = jsonObject.getString("description");

                                // Create a Property object
                                Property property = new Property(uid, name, owner, address, phone, rent, bhk, landmark, latitude, longitude, desc);

                                // Add the property to the search results list
                                searchResults.add(property);

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                        // Notify the adapter that the data has changed
                        listViewAdapter.notifyDataSetChanged();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Handle error response
                    }
                });

        // Add the request to the RequestQueue
        requestQueue.add(jsonArrayRequest);
    }

    private class PropertyAdapter extends ArrayAdapter<Property> {
        PropertyAdapter() {
            super(SearchProperty.this, R.layout.list_item_property, searchResults);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item_property, parent, false);
            }

            TextView nameTextView = convertView.findViewById(R.id.tvPropertyName);
            TextView ownerTextView = convertView.findViewById(R.id.tvPropertyOwner);
            TextView addressTextView = convertView.findViewById(R.id.tvPropertyAddress);
            TextView phoneTextView = convertView.findViewById(R.id.tvPropertyPhone);
            TextView uniqueIdTextView = convertView.findViewById(R.id.tvPropertyUniqueId);

            Property property = getItem(position);

            nameTextView.setText(property.getName());
            ownerTextView.setText("Owner: " + property.getOwner());
            addressTextView.setText("Address: " + property.getAddress());
            phoneTextView.setText("Phone: " + property.getPhone());
            uniqueIdTextView.setText("Unique ID: " + property.getUniqueid());

            return convertView;
        }
    }
}
