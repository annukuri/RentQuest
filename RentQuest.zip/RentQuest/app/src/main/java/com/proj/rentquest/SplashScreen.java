package com.proj.rentquest;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;


public class SplashScreen extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash);

        // Set up animation
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.fade_in);

        // Find the ImageView in your activity_splash.xml layout
        ImageView splashImageView = findViewById(R.id.splashImageView);

        // Apply animation to the ImageView
        splashImageView.startAnimation(animation);

        // Set a listener to start the next activity after the animation finishes
        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {}

            @Override
            public void onAnimationEnd(Animation animation) {
                // Start the next activity (e.g., MainActivity)
                startActivity(new Intent(SplashScreen.this, MainScreen.class));

                // Finish the splash activity
                finish();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {}
        });
    }
}
