package com.proj.rentquest;

import java.io.Serializable;

public class Property implements Serializable {
    private String uniqueid;
    private String name;
    private String owner;
    private String address;
    private String phone;
    private String rent;
    private String bhk;
    private String landmark;
    private String latitude;
    private String longitude;
    private String description;

    public Property(String uid, String name, String owner, String address, String phone, String rent, String bhk, String landmark,
                    String latitude, String longitude, String description) {
        this.uniqueid = uid;
        this.name = name;
        this.owner = owner;
        this.address = address;
        this.phone = phone;
        this.rent = rent;
        this.bhk = bhk;
        this.landmark = landmark;
        this.latitude = latitude;
        this.longitude = longitude;
        this.description = description;
    }

    // Getters and setters for the properties

    public String getUniqueid() {
        return uniqueid;
    }

    public void setUniqueid(String uniqueid) {
        this.uniqueid = uniqueid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getRent() {
        return rent;
    }

    public void setRent(String rent) {
        this.rent = rent;
    }

    public String getBhk() {
        return bhk;
    }

    public void setBhk(String bhk) {
        this.bhk = bhk;
    }

    public String getLandmark() {
        return landmark;
    }

    public void setLandmark(String landmark) {
        this.landmark = landmark;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}

