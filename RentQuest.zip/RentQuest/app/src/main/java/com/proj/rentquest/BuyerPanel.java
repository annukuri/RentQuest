package com.proj.rentquest;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class BuyerPanel extends Activity implements View.OnClickListener {

    TextView tvRent, tvProperty, tvSearch, tvLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.buyerpanel);

        tvRent = (TextView) findViewById(R.id.tvRent);
        tvProperty = (TextView) findViewById(R.id.tvProperty);
        tvSearch = (TextView) findViewById(R.id.tvSearch);
        tvLogout = (TextView) findViewById(R.id.tvLogout);

        tvRent.setOnClickListener(this);
        tvProperty.setOnClickListener(this);
        tvSearch.setOnClickListener(this);
        tvLogout.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.tvRent:
                Intent i = new Intent(this, ViewAllRent.class);
                startActivity(i);
                break;

            case R.id.tvProperty:
                Intent p = new Intent(this, ViewProperty.class);
                startActivity(p);
                break;
            case R.id.tvLogout:
                finish();
                break;
            case R.id.tvSearch:
                Intent search = new Intent(this, SearchProperty.class);
                startActivity(search);
                break;
        }
    }
}
