package com.proj.rentquest;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class PropertyDetailsActivity extends Activity {

    private TextView tvUid;
    private TextView tvName;
    private TextView tvOwner;
    private TextView tvAddress;
    private TextView tvPhone;
    private TextView tvRent;
    private TextView tvBhk;
    private TextView tvLandmark;
    private TextView tvLatitude;
    private TextView tvLongitude;
    private TextView tvDesc;
    private Button btnSendMessage;
    private Button btnMakeCall;
    private Button btnShowMap;
    private WebView webViewMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.property_details);

        // Get the property data from the intent extras
        Intent intent = getIntent();
        if (intent != null) {
            String uid = intent.getStringExtra("uniqueid");
            String name = intent.getStringExtra("name");
            String owner = intent.getStringExtra("owner");
            String address = intent.getStringExtra("address");
            String phone = intent.getStringExtra("phone");
            String rent = intent.getStringExtra("rent");
            String bhk = intent.getStringExtra("bhk");
            String landmark = intent.getStringExtra("landmark");
            String latitude = intent.getStringExtra("latitude");
            String longitude = intent.getStringExtra("longitude");
            String desc = intent.getStringExtra("desc");

            // Initialize the TextViews
            tvUid = findViewById(R.id.tvUid);
            tvName = findViewById(R.id.tvName);
            tvOwner = findViewById(R.id.tvOwner);
            tvAddress = findViewById(R.id.tvAddress);
            tvPhone = findViewById(R.id.tvPhone);
            tvRent = findViewById(R.id.tvRent);
            tvBhk = findViewById(R.id.tvBhk);
            tvLandmark = findViewById(R.id.tvLandmark);
            tvLatitude = findViewById(R.id.tvLatitude);
            tvLongitude = findViewById(R.id.tvLongitude);
            tvDesc = findViewById(R.id.tvDesc);

            // Initialize the buttons
            btnSendMessage = findViewById(R.id.btnSendMessage);
            btnMakeCall = findViewById(R.id.btnMakeCall);
            btnShowMap = findViewById(R.id.btnShowMap);

            // Initialize the WebView
            webViewMap = findViewById(R.id.webViewMap);
            webViewMap.setWebViewClient(new WebViewClient());
            WebSettings webSettings = webViewMap.getSettings();
            webSettings.setJavaScriptEnabled(true);

            // Set the property data to the TextViews
            tvUid.setText("Unique ID: " + uid);
            tvName.setText("Name: " + name);
            tvOwner.setText("Owner: " + owner);
            tvAddress.setText("Address: " + address);
            tvPhone.setText("Phone: " + phone);
            tvRent.setText("Rent: " + rent);
            tvBhk.setText("BHK: " + bhk);
            tvLandmark.setText("Landmark: " + landmark);
            tvLatitude.setText("Latitude: " + latitude);
            tvLongitude.setText("Longitude: " + longitude);
            tvDesc.setText("Description: " + desc);

            // Set button click listeners
            btnSendMessage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    sendMessage(phone);
                }
            });

            btnMakeCall.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    makeCall(phone);
                }
            });

            btnShowMap.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showMap(latitude, longitude);
                }
            });
        }
    }

    private void sendMessage(String phoneNumber) {
        Uri uri = Uri.parse("smsto:" + phoneNumber);
        Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
        intent.putExtra("sms_body", "Hello! I'm interested in your property.");
        startActivity(intent);
    }

    private void makeCall(String phoneNumber) {
        Uri uri = Uri.parse("tel:" + phoneNumber);
        Intent intent = new Intent(Intent.ACTION_CALL, uri);
        startActivity(intent);
    }

    private void showMap(String latitude, String longitude) {
        String url = "https://www.google.com/maps?q=" + latitude + "," + longitude;
        webViewMap.loadUrl(url);
    }
}
