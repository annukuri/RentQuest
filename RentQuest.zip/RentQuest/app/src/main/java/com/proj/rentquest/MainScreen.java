package com.proj.rentquest;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainScreen extends Activity implements View.OnClickListener {

    TextView tvAuthor, tvSales, tvPurchase, tvExit;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainscreen);

        tvAuthor = (TextView) findViewById(R.id.tvAuthor);
        tvSales = (TextView) findViewById(R.id.tvSales);
        tvPurchase = (TextView) findViewById(R.id.tvPurchase);
        tvExit = (TextView) findViewById(R.id.tvExit);

        tvAuthor.setOnClickListener(this);
        tvSales.setOnClickListener(this);
        tvPurchase.setOnClickListener(this);
        tvExit.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.tvAuthor:
                Intent admin = new Intent(this, AuthorActivity.class);
                startActivity(admin);
                break;

            case R.id.tvSales:
                Intent sales = new Intent(this, LoginSeller.class);
                startActivity(sales);
                break;

            case R.id.tvPurchase:
                Intent purchase = new Intent(this, LoginBuyer.class);
                startActivity(purchase);
                break;

            case R.id.tvExit:
                finish();
                break;
        }
    }
}
