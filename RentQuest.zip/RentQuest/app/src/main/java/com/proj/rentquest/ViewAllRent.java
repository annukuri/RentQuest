package com.proj.rentquest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


import android.app.Activity;

import android.os.Bundle;
import android.view.Window;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ViewAllRent extends Activity {
    ViewRentAdapter adapter;
    ListView lstView;
    ArrayList<HashMap<String, String>> arraylist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.viewrent);


        lstView = (ListView) findViewById(R.id.lstViewAllProperty);
        getProperties();
    }

    private void getProperties() {
        RequestQueue queue = Volley.newRequestQueue(this);
        String url = "http://" + Config.ipAddress + "/RentQuestWeb/GetAllRent.php";

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        List<PropertyModel> items = new ArrayList<>();
                        arraylist = new ArrayList<HashMap<String, String>>();

                        //Toast.makeText(getApplicationContext(), ""+response, Toast.LENGTH_LONG).show();

                        try {
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject jsonObject = response.getJSONObject(i);
                                HashMap<String, String> map = new HashMap<String, String>();
                                map.put("id", jsonObject.getString("id"));
                                map.put("uniqueid", jsonObject.getString("uniqueid"));
                                map.put("name", jsonObject.getString("name"));
                                map.put("phone", jsonObject.getString("phone"));
                                map.put("address", jsonObject.getString("address"));
                                map.put("owner", jsonObject.getString("owner"));
                                map.put("rentpermonth", jsonObject.getString("rentpermonth"));
                                map.put("bhk", jsonObject.getString("bhk"));
                                map.put("description", jsonObject.getString("description"));
                                map.put("landmark", jsonObject.getString("landmark"));
                                map.put("latitude", jsonObject.getString("latitude"));
                                map.put("longitude", jsonObject.getString("longitude"));
                                map.put("status", jsonObject.getString("status"));
                                map.put("liked", jsonObject.getString("liked"));
                                map.put("booked", jsonObject.getString("booked"));
                                map.put("filename", jsonObject.getString("filename"));
                                map.put("filepath", jsonObject.getString("filepath"));

                                arraylist.add(map);
                            }
                            adapter = new ViewRentAdapter(ViewAllRent.this, arraylist);
                            lstView.setAdapter(adapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                });

        queue.add(jsonArrayRequest);
    }
}