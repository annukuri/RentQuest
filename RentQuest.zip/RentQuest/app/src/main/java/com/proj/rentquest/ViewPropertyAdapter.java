package com.proj.rentquest;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;

public class ViewPropertyAdapter extends BaseAdapter {

    Context context;
    LayoutInflater inflater;

    ArrayList<HashMap<String, String>> arrLstData;

    HashMap<String, String> hashMapResult = new HashMap<String, String>();

    TextView tvname;
    TextView tvaddress;
    TextView tvowner;
    TextView tvphone;
    ImageView ivUploadedImage;
    String imagepath;

    public ViewPropertyAdapter(Context context,
                           ArrayList<HashMap<String, String>> arraylist) {
        this.context = context;
        arrLstData = arraylist;
    }

    @Override
    public int getCount() {
        return arrLstData.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View itemView = inflater.inflate(R.layout.lst_prop_items, parent,
                false);

        hashMapResult = arrLstData.get(position);

        tvname = (TextView) itemView.findViewById(R.id.tvname);
        tvphone = (TextView) itemView.findViewById(R.id.tvphone);
        tvaddress = (TextView) itemView.findViewById(R.id.tvaddress);
        tvowner = (TextView) itemView.findViewById(R.id.tvowner);


        ivUploadedImage = (ImageView) itemView.findViewById(R.id.ivUploadImage);

        tvname.setText(hashMapResult.get("name"));
        tvowner.setText(hashMapResult.get("owner"));
        tvaddress.setText(hashMapResult.get("address"));
        tvphone.setText(hashMapResult.get("phone"));

        imagepath = "http://"+Config.ipAddress+"/RentQuestWeb/uploads/"+hashMapResult.get("buildingimage");

        Picasso.get()
                .load(imagepath)
                .into(ivUploadedImage);

        itemView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // Get the position
                hashMapResult = arrLstData.get(position);

                Intent intent = new Intent(context, ViewSingleProperty.class);
                intent.putExtra("id", hashMapResult.get("id"));
                intent.putExtra("uniqueid",hashMapResult.get("uniqueid"));
                intent.putExtra("name",hashMapResult.get("name"));
                intent.putExtra("owner", hashMapResult.get("owner"));
                intent.putExtra("phone", hashMapResult.get("phone"));
                intent.putExtra("address", hashMapResult.get("address"));
                intent.putExtra("landmark", hashMapResult.get("landmark"));
                intent.putExtra("latitude", hashMapResult.get("latitude"));
                intent.putExtra("longitude", hashMapResult.get("longitude"));
                intent.putExtra("description", hashMapResult.get("description"));
                intent.putExtra("status", hashMapResult.get("status"));
                intent.putExtra("liked", hashMapResult.get("liked"));
                //intent.putExtra("booked", hashMapResult.get("booked"));
                intent.putExtra("buildingimage", hashMapResult.get("buildingimage"));
                intent.putExtra("documentimage", hashMapResult.get("documentimage"));

                context.startActivity(intent);
            }
        });
        return itemView;
    }
}