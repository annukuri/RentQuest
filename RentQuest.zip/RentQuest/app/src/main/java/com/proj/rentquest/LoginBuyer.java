package com.proj.rentquest;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;


import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class LoginBuyer extends Activity implements View.OnClickListener {

    String TAG = "com.proj.rentquest";

    private static final String URL = "http://" + Config.ipAddress + "/RentQuestWeb/LoginBuyer.php"; // Replace with your PHP registration URL

    Dialog progressDialog;
    public TextView txtForgotPassword, txtDismiss, txtDescription, txtMessage,
            txtHeader;

    String ip;
    HashMap<String, String> map = new HashMap<String, String>();
    String response = null;
    String username ;
    String password ;
    private RequestQueue requestQueue;



    EditText etUsername, etPassword;
    Button btnLogin;
    TextView reg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_user);
        ip = Config.ipAddress;

        requestQueue = Volley.newRequestQueue(this);

        etUsername = (EditText) findViewById(R.id.etUserName);
        etPassword = (EditText) findViewById(R.id.etUserPass);
        reg = (TextView) findViewById(R.id.reg);
        btnLogin = (Button) findViewById(R.id.btnLoginUser);
        btnLogin.setOnClickListener(this);
        reg.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnLoginUser:
                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();
                if (!username.equalsIgnoreCase("")
                        && !password.equalsIgnoreCase("")) {
                    makeLogin(username, password);

                } else {
                    Toast.makeText(this, "Wrong User Name Password Wrong", Toast.LENGTH_LONG).show();
                }
                break;

            case R.id.reg:
                Intent reg = new Intent(this, RegisterBuyer.class);
                startActivity(reg);
                break;
        }
    }

    private void makeLogin(String username, String password) {

        StringRequest request = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Toast.makeText(LoginBuyer.this, response, Toast.LENGTH_SHORT).show();

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            boolean success = jsonObject.getBoolean("success");
                            String message = jsonObject.getString("message");

                            Toast.makeText(LoginBuyer.this, message, Toast.LENGTH_SHORT).show();
                            if(success){
                                Intent i = new Intent(LoginBuyer.this, BuyerPanel.class);
                                startActivity(i);

                            }else{
                                Toast.makeText(LoginBuyer.this, "Login Failed due to incorrect credentials", Toast.LENGTH_SHORT).show();

                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        // Handle the response from the server


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(LoginBuyer.this, "Registration failed", Toast.LENGTH_SHORT).show();
                        // Handle error
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("username", username);
                params.put("password", password);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }
}