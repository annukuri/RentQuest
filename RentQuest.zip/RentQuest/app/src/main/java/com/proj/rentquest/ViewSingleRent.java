package com.proj.rentquest;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

public class ViewSingleRent extends Activity implements OnClickListener {

    String filename;
    String id;
    String name;
    String phone;
    String address;
    String owner;
    String filepath;
    String imagepath;
    String uniqueid, rentpermonth, bhk, landmark, latitude, longitude, description, status, liked, booked;

    TextView tvViewUser, tvViewPhone, tvViewOwner, tvViewAddress;
    TextView tvuniqueid, tvrentpermonth, tvbhk, tvlandmark, tvlatitude, tvlongitude, tvdescription, tvstatus, tvliked, tvbooked;
    ImageView imgViewImg;
    Button btnCall, btnClose, btnLike, btnBook;
    WebView webViewLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewsinglerent);

        Intent intent = getIntent();
        id = intent.getStringExtra("id");
        name = intent.getStringExtra("name");
        phone = intent.getStringExtra("phone");
        owner = intent.getStringExtra("owner");
        address = intent.getStringExtra("address");
        filepath = intent.getStringExtra("filepath");
        filename = intent.getStringExtra("filename");
        uniqueid = intent.getStringExtra("uniqueid");
        rentpermonth = intent.getStringExtra("rentpermonth");
        bhk = intent.getStringExtra("bhk");
        landmark = intent.getStringExtra("landmark");
        latitude = intent.getStringExtra("latitude");
        longitude = intent.getStringExtra("longitude");
        description = intent.getStringExtra("description");
        status = intent.getStringExtra("status");
        liked = intent.getStringExtra("liked");
        booked = intent.getStringExtra("booked");

        Toast.makeText(this, id + " " + name + " " + phone + " " + owner + " " + address, Toast.LENGTH_LONG).show();

        tvViewUser = findViewById(R.id.tvPname);
        tvViewPhone = findViewById(R.id.tvPPhone);
        tvViewOwner = findViewById(R.id.tvPowner);
        tvViewAddress = findViewById(R.id.tvPAddress);
        imgViewImg = findViewById(R.id.imgViewImg);
        tvuniqueid = findViewById(R.id.tvuniqueid);
        tvrentpermonth = findViewById(R.id.tvrentpermonth);
        tvbhk = findViewById(R.id.tvbhk);
        tvlandmark = findViewById(R.id.tvlandmark);
        tvdescription = findViewById(R.id.tvdescription);
        tvbooked = findViewById(R.id.tvbooked);
        btnClose = findViewById(R.id.btnClose);
        btnCall = findViewById(R.id.btnCall);
        btnLike = findViewById(R.id.btnLike);
        btnBook = findViewById(R.id.btnBook);
        webViewLocation = findViewById(R.id.webViewLocation);

        btnCall.setOnClickListener(this);
        btnClose.setOnClickListener(this);

        btnLike.setOnClickListener(this);
        btnBook.setOnClickListener(this);

        imagepath = "http://" + Config.ipAddress + "/RentQuestWeb/uploads/" + filename;
        Picasso.get().load(imagepath).into(imgViewImg);

        tvViewUser.setText("Property Type: " + name);
        tvViewPhone.setText("Phone: " + phone);
        tvViewOwner.setText("Owner: " + owner);
        tvViewAddress.setText("Address: " + address);
        tvuniqueid.setText("Unique ID: " + uniqueid);
        tvrentpermonth.setText("Rent Per Month: " + rentpermonth);
        tvbhk.setText("BHK: " + bhk);
        tvlandmark.setText("Landmark: " + landmark);
        tvdescription.setText("Description: " + description);
        tvbooked.setText("Status: " + booked);

        setupWebView();
    }

    private void setupWebView() {
        webViewLocation.setWebViewClient(new WebViewClient());
        WebSettings webSettings = webViewLocation.getSettings();
        webSettings.setJavaScriptEnabled(true);

        String url = "https://maps.google.com/maps?q=" + latitude + "," + longitude;
        webViewLocation.loadUrl(url);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnClose:
                finish();
                break;

            case R.id.btnCall:
                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:" + phone));
                startActivity(callIntent);
                break;


            case R.id.btnLike:
                updateLikeStatus();
                break;

            case R.id.btnBook:
                updateBookStatus();
                break;
        }
    }

    private void updateLikeStatus() {
        // Replace "YOUR_UPDATE_LIKE_URL" with the appropriate URL for updating the like status
        String updateLikeUrl = "http://"+Config.ipAddress+"/RentQuestWeb/UpdateRentLiked.php?id=" + id;

        StringRequest updateLikeRequest = new StringRequest(Request.Method.GET, updateLikeUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Handle the response after successfully updating the like status
                        // You can show a toast message or perform any other action
                        Toast.makeText(ViewSingleRent.this, "Like status updated", Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Handle the error response if the like status update fails
                        // You can show a toast message or perform any other action
                        Toast.makeText(ViewSingleRent.this, "Error updating like status", Toast.LENGTH_SHORT).show();
                    }
                });

        Volley.newRequestQueue(this).add(updateLikeRequest);
    }

    private void updateBookStatus() {
        // Replace "YOUR_UPDATE_BOOK_URL" with the appropriate URL for updating the book status
        String updateBookUrl = "http://"+Config.ipAddress+"/RentQuestWeb/UpdateRentBooked.php?id=" + id;

        StringRequest updateBookRequest = new StringRequest(Request.Method.GET, updateBookUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Handle the response after successfully updating the book status
                        // You can show a toast message or perform any other action
                        Toast.makeText(ViewSingleRent.this, "Book status updated", Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Handle the error response if the book status update fails
                        // You can show a toast message or perform any other action
                        Toast.makeText(ViewSingleRent.this, "Error updating book status", Toast.LENGTH_SHORT).show();
                    }
                });

        Volley.newRequestQueue(this).add(updateBookRequest);
    }
}
