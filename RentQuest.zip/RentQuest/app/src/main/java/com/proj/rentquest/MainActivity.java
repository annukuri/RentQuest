package com.proj.rentquest;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity implements View.OnClickListener {

    Button btnBuyer, btnSeller, btnExit, btnAdmin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnBuyer = (Button) findViewById(R.id.btnBuyer);
        btnSeller = (Button) findViewById(R.id.btnSeller);
        btnAdmin = (Button) findViewById(R.id.btnAdmin);
        btnExit = (Button) findViewById(R.id.btnExit);

        btnBuyer.setOnClickListener(this);
        btnSeller.setOnClickListener(this);
        btnExit.setOnClickListener(this);
        btnAdmin.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnSeller:
                Intent seller = new Intent(MainActivity.this, LoginSeller.class);
                startActivity(seller);
                break;
            case R.id.btnBuyer:
                Intent buyer = new Intent(MainActivity.this, LoginBuyer.class);
                startActivity(buyer);
                break;
            case R.id.btnAdmin:
                Intent admin = new Intent(MainActivity.this, LoginAdmin.class);
                startActivity(admin);
                break;
            case R.id.btnExit:
                finish();
                break;
        }
    }
}