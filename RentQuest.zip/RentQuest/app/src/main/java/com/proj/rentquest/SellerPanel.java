package com.proj.rentquest;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.TextView;

public class SellerPanel extends Activity implements View.OnClickListener {

    TextView tvRent,tvProperty ,tvHelp, tvLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sellerpanel);

        tvRent = (TextView) findViewById(R.id.tvRent);
        tvProperty = (TextView) findViewById(R.id.tvProperty);
        tvHelp = (TextView) findViewById(R.id.tvHelp);

        tvLogout = (TextView) findViewById(R.id.tvLogout);


        tvRent.setOnClickListener(this);
        tvProperty.setOnClickListener(this);
        tvHelp.setOnClickListener(this);
        tvLogout.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {

            case R.id.tvRent:
                Intent add = new Intent(SellerPanel.this, AddRent.class);
                startActivity(add);
                break;

            case R.id.tvProperty:
                Intent build = new Intent(SellerPanel.this, AddProperty.class);
                startActivity(build);
                break;

            case R.id.tvHelp:
                /*Intent add = new Intent(SellerPanel.this, AddRent.class);
                startActivity(add);*/
                break;

            case R.id.tvLogout:
                finish();
                break;

        }
    }
}