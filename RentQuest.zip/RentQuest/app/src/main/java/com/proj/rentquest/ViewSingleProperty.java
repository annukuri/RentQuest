package com.proj.rentquest;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.Map;

public class ViewSingleProperty extends Activity implements View.OnClickListener {

    String filename;
    String id;
    String name;
    String phone;
    String address;
    String owner;
    String filepath, buildingimage, documentimage;
    String imagepath, docimagepath;
    String uniqueid, rentpermonth, bhk, landmark, latitude, longitude, description, status, liked, booked;

    TextView tvViewUser, tvViewPhone, tvViewOwner, tvViewAddress;
    TextView tvuniqueid, tvlandmark, tvdescription, tvbooked;
    ImageView imgViewImg, imgViewPropDocImg;
    Button btnCall, btnClose, btnLike, btnBook;
    WebView webViewLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewsingleprop);

        Intent intent = getIntent();
        id = intent.getStringExtra("id");
        name = intent.getStringExtra("name");
        phone = intent.getStringExtra("phone");
        owner = intent.getStringExtra("owner");
        address = intent.getStringExtra("address");
        buildingimage = intent.getStringExtra("buildingimage");
        documentimage = intent.getStringExtra("documentimage");
        uniqueid = intent.getStringExtra("uniqueid");
        landmark = intent.getStringExtra("landmark");
        latitude = intent.getStringExtra("latitude");
        longitude = intent.getStringExtra("longitude");
        description = intent.getStringExtra("description");
        status = intent.getStringExtra("status");
        liked = intent.getStringExtra("liked");
        booked = intent.getStringExtra("booked");

        Toast.makeText(this, id + " " + name + " " + phone + " " + owner + " " + address, Toast.LENGTH_LONG).show();

        tvViewUser = findViewById(R.id.tvPname);
        tvViewPhone = findViewById(R.id.tvPPhone);
        tvViewOwner = findViewById(R.id.tvPowner);
        tvViewAddress = findViewById(R.id.tvPAddress);
        imgViewImg = findViewById(R.id.imgViewImg);
        imgViewPropDocImg = findViewById(R.id.imgViewPropDocImg);
        tvuniqueid = findViewById(R.id.tvuniqueid);
        tvlandmark = findViewById(R.id.tvlandmark);
        tvdescription = findViewById(R.id.tvdescription);
        tvbooked = findViewById(R.id.tvbooked);
        btnClose = findViewById(R.id.btnClose);
        btnCall = findViewById(R.id.btnCall);
        btnLike = findViewById(R.id.btnLike);
        btnBook = findViewById(R.id.btnBook);
        webViewLocation = findViewById(R.id.webViewLocation);

        btnClose.setOnClickListener(this);
        btnCall.setOnClickListener(this);
        btnLike.setOnClickListener(this);
        btnBook.setOnClickListener(this);

        imagepath = "http://" + Config.ipAddress + "/RentQuestWeb/uploads/" + buildingimage;
        Picasso.get().load(imagepath).into(imgViewImg);

        docimagepath = "http://" + Config.ipAddress + "/RentQuestWeb/uploads/" + documentimage;
        Picasso.get().load(docimagepath).into(imgViewPropDocImg);

        tvViewUser.setText("Property Type: " + name);
        tvViewPhone.setText("Phone: " + phone);
        tvViewOwner.setText("Owner: " + owner);
        tvViewAddress.setText("Address: " + address);
        tvuniqueid.setText("Unique ID: " + uniqueid);
        tvlandmark.setText("Landmark: " + landmark);
        tvdescription.setText("Description: " + description);
        tvbooked.setText("Status: " + booked);

        // Load location in WebView
        String url = "https://maps.google.com/maps?q=" + latitude + "," + longitude;
        webViewLocation.setWebViewClient(new WebViewClient());
        webViewLocation.getSettings().setJavaScriptEnabled(true);
        webViewLocation.loadUrl(url);
    }

    @Override
    public void onClick(View arg0) {
        switch (arg0.getId()) {
            case R.id.btnClose:
                finish();
                break;

            case R.id.btnCall:
                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:" + phone));
                startActivity(callIntent);
                break;

            case R.id.btnLike:
                // Perform like functionality here
                updateLikeStatus();
                break;

            case R.id.btnBook:
                // Perform book functionality here
                updateBookedStatus();
                break;
        }
    }

    private void updateLikeStatus() {
        // Send a network request to update the like status using Volley
        String url = "http://" + Config.ipAddress + "/RentQuestWeb/UpdatePropertyLiked.php";
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Handle the response from the server
                        Toast.makeText(ViewSingleProperty.this, response, Toast.LENGTH_SHORT).show();
                        /*if (response.equals("success")) {
                            Toast.makeText(ViewSingleProperty.this, "Liked", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(ViewSingleProperty.this, "Like Failed", Toast.LENGTH_SHORT).show();
                        }*/
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(ViewSingleProperty.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                // Parameters to be sent to the server
                Map<String, String> params = new HashMap<>();
                params.put("id", id); // Pass the property ID
                // Add any additional parameters if required
                return params;
            }
        };

        // Add the request to the RequestQueue
        Volley.newRequestQueue(this).add(request);
    }

    private void updateBookedStatus() {
        // Send a network request to update the booked status using Volley
        String url = "http://" + Config.ipAddress + "/RentQuestWeb/UpdatePropertyBooked.php";
        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Handle the response from the server
                        Toast.makeText(ViewSingleProperty.this, response, Toast.LENGTH_SHORT).show();
                        /*if (response.equals("success")) {
                            Toast.makeText(ViewSingleProperty.this, "Booked", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(ViewSingleProperty.this, "Booking Failed", Toast.LENGTH_SHORT).show();
                        }*/
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(ViewSingleProperty.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                // Parameters to be sent to the server
                Map<String, String> params = new HashMap<>();
                params.put("id", id); // Pass the property ID
                // Add any additional parameters if required
                return params;
            }
        };

        // Add the request to the RequestQueue
        Volley.newRequestQueue(this).add(request);
    }
}
