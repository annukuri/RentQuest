package com.proj.rentquest;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginAdmin extends Activity implements View.OnClickListener {

    String URL = "http://"+Config.ipAddress+"/RentQuestWeb/LoginAdmin.php";

    String adminid, password;

    EditText etAdminid, etAdminPass;
    Button btnLoginAdmin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loginadmin);

        etAdminid = (EditText) findViewById(R.id.etAdminid);
        etAdminPass = (EditText) findViewById(R.id.etAdminPass);
        btnLoginAdmin = (Button) findViewById(R.id.btnLoginAdmin);

        btnLoginAdmin.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnLoginAdmin:
                getData();
                loginAdmin(adminid, password);
                break;
        }
    }

    private void loginAdmin(String adminid, String password) {


        StringRequest request = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(LoginAdmin.this, response, Toast.LENGTH_SHORT).show();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            boolean success = jsonObject.getBoolean("success");
                            String message = jsonObject.getString("message");

                            Toast.makeText(LoginAdmin.this, message, Toast.LENGTH_SHORT).show();

                            if (success) {
                                Intent i = new Intent(LoginAdmin.this, AdminPanel.class);
                                startActivity(i);

                            } else {
                                Toast.makeText(LoginAdmin.this, "Incorrect Credentials", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(LoginAdmin.this, "Registration failed", Toast.LENGTH_SHORT).show();
                        // Handle error
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("adminid", adminid);
                params.put("password", password);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }

    private void getData() {
        adminid = this.etAdminid.getText().toString();
        password = this.etAdminPass.getText().toString();
    }
}