package com.proj.rentquest;

import android.app.Activity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class RegisterSeller extends Activity implements View.OnClickListener {

    EditText etRegName, etRegPhone, etRegPassword, etRegEmail, etRegPlace, etOtp;
    String strRegName, strRegPhone, strRegPassword, strRegEmail, strRegPlace, strOtp;
    Button btnRegRegister, btnVerifyOtp;

    String result = null;

    private static final String URL = "http://" + Config.ipAddress + "/RentQuestWeb/RegisterSeller.php"; // Replace with your PHP registration URL

    private RequestQueue requestQueue;

    private String generatedOtp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registerseller);
        initializeComponents();
        requestQueue = Volley.newRequestQueue(getApplicationContext());
    }

    private void initializeComponents() {
        etRegName = findViewById(R.id.etRegName);
        etRegPhone = findViewById(R.id.etRegPhone);
        etRegPassword = findViewById(R.id.etRegPassword);
        etRegEmail = findViewById(R.id.etRegEmail);
        etRegPlace = findViewById(R.id.etRegPlace);
        btnRegRegister = findViewById(R.id.btnRegRegister);
        btnVerifyOtp = findViewById(R.id.btnVerifyOtp);
        etOtp = findViewById(R.id.etOtp);

        btnRegRegister.setOnClickListener(this);
        btnVerifyOtp.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnRegRegister:
                getAllData();

                if (!strRegName.equalsIgnoreCase("")
                        && !strRegPhone.equalsIgnoreCase("")
                        && !strRegPassword.equalsIgnoreCase("")
                        && !strRegEmail.equalsIgnoreCase("")) {

                    // Generate OTP
                    generatedOtp = generateOTP();

                    // Send SMS to the registered phone number
                    sendSMS(strRegPhone, "Your verification OTP is: " + generatedOtp);

                    Toast.makeText(getApplicationContext(),
                            "OTP has been sent to your registered phone number.",
                            Toast.LENGTH_LONG).show();

                    btnVerifyOtp.setVisibility(View.VISIBLE);
                    etOtp.setVisibility(View.VISIBLE);
                } else {
                    Toast.makeText(getApplicationContext(),
                                    "Error: Please Fill All the Fields", Toast.LENGTH_LONG)
                            .show();
                }
                break;

            case R.id.btnVerifyOtp:
                strOtp = etOtp.getText().toString().trim();
                if (strOtp.equals(generatedOtp)) {
                    register(strRegName, strRegPhone, strRegEmail, strRegPassword, strRegPlace);
                } else {
                    Toast.makeText(getApplicationContext(),
                            "Invalid OTP. Please enter the correct OTP.",
                            Toast.LENGTH_LONG).show();
                }
                break;
        }
    }

    private void getAllData() {
        strRegName = etRegName.getText().toString();
        strRegPhone = etRegPhone.getText().toString();
        strRegPassword = etRegPassword.getText().toString();
        strRegEmail = etRegEmail.getText().toString();
        strRegPlace = etRegPlace.getText().toString();
    }

    private void sendSMS(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void register(String username, String phone, String email, String password, String place) {
        StringRequest request = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            boolean success = jsonObject.getBoolean("success");
                            String message = jsonObject.getString("message");

                            Toast.makeText(RegisterSeller.this, message, Toast.LENGTH_SHORT).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(RegisterSeller.this, "Registration failed", Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("username", username);
                params.put("email", email);
                params.put("password", password);
                params.put("phone", phone);
                params.put("place", place);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }

    private String generateOTP() {
        Random random = new Random();
        int otp = 100000 + random.nextInt(900000);
        return String.valueOf(otp);
    }
}
