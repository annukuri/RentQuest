package com.proj.rentquest;

public class Config {

    public static String ipAddress = "192.168.43.178";
    public static String idforproperty = "100";
}
