package com.proj.rentquest;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class AddProperty extends Activity implements View.OnClickListener {

    private static final String URL = "http://" + Config.ipAddress + "/RentQuestWeb/AddProperty.php"; // Replace with your PHP registration URL

    Button btnAddBuilding;
    EditText etUid, etName, etAdd, etOwner, etPhone,etLandmark, etLatitude, etLongitude, etDesc;
    String uid, name, add, owner, phone, lat, lan, desc,landmark;


    private LocationManager locationManager;
    private LocationListener locationListener;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addproperty);

        Config.idforproperty = getUniqueID();

        etUid = (EditText) findViewById(R.id.etUid);
        etName = (EditText) findViewById(R.id.etName);
        etAdd = (EditText) findViewById(R.id.etAdd);
        etOwner = (EditText) findViewById(R.id.etOwner);
        etPhone = (EditText) findViewById(R.id.etPhone);
        etLatitude = (EditText) findViewById(R.id.etLatitude);
        etLongitude = (EditText) findViewById(R.id.etLongitude);
        etDesc = (EditText) findViewById(R.id.etDesc);
        etLandmark = (EditText) findViewById(R.id.etLandMark);

        btnAddBuilding = (Button) findViewById(R.id.btnAddBuilding);

        etUid.setText(Config.idforproperty);

        btnAddBuilding.setOnClickListener(this);

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                double latitude = location.getLatitude();
                double longitude = location.getLongitude();
                // Do something with the latitude and longitude values
                // For example, display them in a TextView
                etLatitude.setText("" + latitude);
                etLongitude.setText("" + longitude);
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {
            }

            @Override
            public void onProviderEnabled(String provider) {
            }

            @Override
            public void onProviderDisabled(String provider) {
            }
        };

        // Check location permission
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // Request location permission if not granted
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        } else {
            // Request location updates
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
        }
    }

    private String getUniqueID() {
        String prefix = "PROP";
        int numberLength = 10 - prefix.length();
        Random random = new Random();
        int randomNumber = random.nextInt((int) Math.pow(10, numberLength));
        String formattedNumber = String.format("%0" + numberLength + "d", randomNumber);
        String finalNumber = prefix + formattedNumber;
        return finalNumber;
    }

    private void addBuilding(String uid, String name, String owner, String address, String phone, String landmark, String desc, String lat, String lan) {

        StringRequest request = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            boolean success = jsonObject.getBoolean("success");
                            String message = jsonObject.getString("message");

                            Toast.makeText(AddProperty.this, message, Toast.LENGTH_SHORT).show();

                            if (success) {
                                Toast.makeText(AddProperty.this, message, Toast.LENGTH_SHORT).show();
                                Intent addbuildimg = new Intent(AddProperty.this, AddPropertyImage.class);
                                addbuildimg.putExtra("PropID",Config.idforproperty);
                                startActivity(addbuildimg);
                            } else {
                                Toast.makeText(AddProperty.this, "Cannot Add", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        // Handle the response from the server
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(AddProperty.this, "Registration failed" + error.toString(), Toast.LENGTH_SHORT).show();
                        // Handle error
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                //bhk, rent, landmark, desc
                Map<String, String> params = new HashMap<>();
                params.put("uid", uid);
                params.put("name", name);
                params.put("owner", owner);
                params.put("address", address);
                params.put("phone", phone);
                params.put("landmark", landmark);
                params.put("descn", desc);
                params.put("lat", lat);
                params.put("lan", lan);

                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnAddBuilding:

                uid = etUid.getText().toString();
                name = etName.getText().toString();
                add = etAdd.getText().toString();
                owner = etOwner.getText().toString();
                phone = etPhone.getText().toString();
                lat = etLatitude.getText().toString();
                lan = etLongitude.getText().toString();
                desc = etDesc.getText().toString();
                landmark= etLandmark.getText().toString();

                addBuilding( uid,  name,  owner, add, phone, landmark, desc, lat, lan);

                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Request location updates
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
                }
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Remove location updates to conserve battery life
        locationManager.removeUpdates(locationListener);
    }
}
