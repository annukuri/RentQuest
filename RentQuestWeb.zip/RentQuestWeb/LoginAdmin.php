<?php

error_reporting(E_ERROR);

$DB_HOST = "localhost";
$DB_UID = "root";
$DB_PASS = "";
$DB_NAME = "rentquest";

$db_con = mysqli_connect($DB_HOST, $DB_UID, $DB_PASS) or die('Unable to Connect Database');

mysqli_select_db($db_con, $DB_NAME);

$adminid = $_GET["adminid"];
$password = $_GET["password"];

$sql = "select * from admin where adminid='$adminid' and password='$password'";

$result1 = mysqli_query($db_con,$sql);

$row = mysqli_fetch_array($result1);

if ($row['phone'] == $phone && $row['password'] == $password) {
    $result["success"] = true;
    $result["message"] = "Success";
    echo json_encode($result);
} else {
	$result["success"] = false;
    $result["message"] = "Failed to login";
    echo json_encode($result);
}

mysqli_close($db_con);	
?>