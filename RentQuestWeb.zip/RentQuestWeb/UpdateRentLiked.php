<?php

error_reporting(E_ERROR);

$DB_HOST = "localhost";
$DB_UID = "root";
$DB_PASS = "";
$DB_NAME = "rentquest";

$db_con = mysqli_connect($DB_HOST, $DB_UID, $DB_PASS) or die('Unable to Connect to Database');

mysqli_select_db($db_con, $DB_NAME);


$id = $_GET['id'];

$sql = "update rent set liked = 'Like' where id = $id";

$result = mysqli_query($db_con,$sql);

if ($result == "1") {
	echo("Success");
} else {
	echo("Fail");
	exit();
}
mysqli_close($db_con);

?>