<?php
error_reporting(E_ERROR);

//print_r($_POST)

$DB_HOST = "localhost";
$DB_UID = "root";
$DB_PASS = "";
$DB_NAME = "rentquest";

$db_con = mysqli_connect($DB_HOST, $DB_UID, $DB_PASS) or die('Unable to Connect to Database');


mysqli_select_db($db_con, $DB_NAME);
	

    // Handle POST data
	$username = $_POST['username'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$phone = $_POST['phone'];
	$address = $_POST['place'];






// Validate the input fields (implement your own validation logic here)
if (empty($username) || empty($email) || empty($password)) {
    $response['success'] = false;
    $response['message'] = "Please fill all fields required..";
    echo json_encode($response);
    exit();
}

$sql = "select * from seller where phone ='$phone'";

$result = mysqli_query($db_con,$sql);
$row = mysqli_fetch_array($result);

if ($row['phone'] == $phone) {
	$response['success'] = false;
    $response['message'] = "User already Exist";
    echo json_encode($response);
    exit();
}



$sql = "insert into seller(name, email, phone, password, address) values('$username', '$email', '$phone', '$password', '$address')";

//$result1 = mysqli_query($db_con,$sql);


if (mysqli_query($db_con,$sql)) {
	$response['success'] = true;
	$response['message'] = "Registration successful";
	echo json_encode($response);
} else {
	$response['success'] = false;
    $response['message'] = "Unable to insert data...";
    echo json_encode($response);
    //exit();
}
mysqli_close($db_con);

?>