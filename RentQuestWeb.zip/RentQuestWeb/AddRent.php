<?php
error_reporting(E_ERROR);

$DB_HOST = "localhost";
$DB_UID = "root";
$DB_PASS = "";
$DB_NAME = "rentquest";

$db_con = mysqli_connect($DB_HOST, $DB_UID, $DB_PASS) or die('Unable to Connect to Database');

mysqli_select_db($db_con, $DB_NAME);
	
$uid = $_POST['uid'];
$name = $_POST['name'];
$owner = $_POST['owner'];
$address = $_POST['address'];
$phone = $_POST['phone'];
$bhk = $_POST['bhk'];
$landmark = $_POST['landmark'];
$rentpermonth = $_POST['rent'];
$description = $_POST['descn'];
$latitude = $_POST['lat'];
$longitude = $_POST['lan'];
	
$sql = "insert into rent(uniqueid, name, owner, address, phone, rentpermonth, bhk, landmark, latitude, longitude, description) values('$uid', '$name', '$owner', '$address','$phone','$rentpermonth','$bhk','$landmark','$latitude','$longitude','$description')";


if (mysqli_query($db_con,$sql)) {
	$response['success'] = true;
	$response['message'] = "Inserted successful";
	echo json_encode($response);
} else {
	$response['success'] = false;
    $response['message'] = "Unable to insert data...";
    echo json_encode($response);
    //exit();
}
mysqli_close($db_con);

?>