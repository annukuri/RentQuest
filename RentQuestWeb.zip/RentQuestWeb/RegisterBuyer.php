<?php

error_reporting(E_ERROR);

$DB_HOST = "localhost";
$DB_UID = "root";
$DB_PASS = "";
$DB_NAME = "rentquest";

$db_con = mysqli_connect($DB_HOST, $DB_UID, $DB_PASS) or die('Unable to Connect to Database');

mysqli_select_db($db_con, $DB_NAME);


$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];
$phone = $_POST['phone'];
$address = $_POST['place'];

// Validate the input fields (implement your own validation logic here)
if (empty($username) || empty($email) || empty($password)) {
    $response['success'] = false;
    $response['message'] = "Please fill all fields";
    echo json_encode($response);
    exit();
}

$sql = "select * from seller where phone ='$phone'";

$result = mysqli_query($db_con,$sql);
$row = mysqli_fetch_array($result);

if ($row['phone'] == $phone) {
	$response['success'] = false;
    $response['message'] = "User already Exist";
    echo json_encode($response);
    exit();
}


$sql = "insert into buyer(name, email, phone,  password, address)"
        . "values('$name','$email','$phone','$password','$address')";

$result = mysqli_query($db_con,$sql);

if ($result == "1") {
	$response['success'] = true;
	$response['message'] = "Registration successful";
	echo json_encode($response);
} else {
	$response['success'] = false;
    $response['message'] = "Not registered";
    echo json_encode($response);
    exit();
}
mysqli_close($db_con);

?>